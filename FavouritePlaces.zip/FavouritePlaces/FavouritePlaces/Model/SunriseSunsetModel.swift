//
//  SunriseSunset.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 20/5/2022.
//

import Foundation

/// **SunriseSunsetModel** conforms to Codable protocol and store the *sunrise* and *sunset* information.
struct SunriseSunsetModel: Codable {
    /// **sunrise** store sunrise information
    var sunrise: String
    /// **sunset** store sunset information
    var sunset: String
}
/// **SunriseSunsetAPI** is designed specifically to decode the Json file that received from the API.
struct SunriseSunsetAPI: Codable {
    var results: SunriseSunsetModel
    var status: String?
}

