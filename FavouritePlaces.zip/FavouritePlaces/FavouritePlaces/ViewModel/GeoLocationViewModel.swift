//
//  GeoLocationViewModel.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 20/5/2022.
//


import Combine
import CoreLocation
import CoreData
import Foundation
import MapKit


/**
    GeoLocationViewModel class
 
    This class will handle all the logics regarding GeoCoding, Reverse GeoCoding, and Sunrise and SunSet API.
 */
class GeoLocationViewModel: ObservableObject {
    /// **region** will be used with *Map* view in *SwiftUI*.
    @Published var region = MKCoordinateRegion()
    /// **sunriseSunset** is used for storing sunrise and sunset information; the default values are "unknown".
    @Published var sunriseSunset = SunriseSunsetModel(sunrise: "unknown", sunset: "unknown")
    /// **name** is used for storing the name that
    @Published var name = ""
    /// Initiate this class with region and name.
    init(region: MKCoordinateRegion, name: String) {
        self.region = region
        self.name = name
    }
    
    /// **sunrise** is used for reading and writing to **sunriseSunset.sunrise**.
    var sunrise: String {
        get { sunriseSunset.sunrise }
        set { sunriseSunset.sunrise = newValue }
    }
    /// **sunset** is used for reading and writing to **sunriseSunset.sunset**.
    var sunset: String {
        get { sunriseSunset.sunset }
        set { sunriseSunset.sunset = newValue }
    }
    
    /**
     getCoordinates function is use for getting the coordinate information when the user type in the place name.
     
        **Usage Example:**
        ```
        getCoordinates(for: "Brisbane")
        ```
        - Parameter name: it takes the name of a place
     */
    func getCoordinates(for name: String) {
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(name) { [self] optionalPlacemarks, optionalError in
            if let error = optionalError {
                print("Error looking up \(name): \(error.localizedDescription)")
                return
            }
            guard let placemarks = optionalPlacemarks, !placemarks.isEmpty else {
                print("Placemarks came back empty")
                return
            }
            let placemark = placemarks[0]
            guard let coordin = placemark.location?.coordinate else {
                print("Placemark has no location")
                return
            }
            
            region.mapLatitude = String(coordin.latitude)
            region.mapLongitude = String(coordin.longitude)

        }
    }
    
    /**
     lookupName function is use for looking for the name of a place when the user input the coordinates.
     
        **Usage Example:**
        ```
        lookupName(for: CLLocation(latitude: 0.0, longitude: 0.0))
        ```
        - Parameter location: it takes the coordinates of a place
     */
    func lookupName(for location: CLLocation) {
        let coder = CLGeocoder()
        coder.reverseGeocodeLocation(location) { optionalPlacemarks, optionalError in
            if let error = optionalError {
                print("Error looking up \(location.coordinate): \(error.localizedDescription)")
                return
            }
            guard let placemarks = optionalPlacemarks, !placemarks.isEmpty else {
                print("Placemarks came back empty")
                return
            }
            let placemark = placemarks[0]
            for value in [
                \CLPlacemark.name,
                \.country,
                \.isoCountryCode,
                \.postalCode,
                \.administrativeArea,
                \.subAdministrativeArea,
                \.locality,
                \.subLocality,
                \.thoroughfare,
                \.subThoroughfare
            ] {
                print(String(describing: placemark[keyPath: value]))
            }
            self.name = placemark.locality ?? placemark.name ?? placemark.subAdministrativeArea ?? placemark.postalCode ?? placemark.country ?? ""
            print(self.name)

        }
    }
    
    /**
     lookupSunriseAndSunset function is use for searching for the sunrise and sunset information.
     
        **Usage Example:**
        ```
        lookupSunriseAndSunset(la: 0.0, long: 0.0)
        ```
        - Parameter latitude: it takes the latitude of a place
        - Parameter longitude: it takes the longitude of a place
     */
    func lookupSunriseAndSunset(la latitude:String, long longitude:String) {
        var placemark: CLPlacemark?
        let cllLocation = CLLocation(latitude: Double(latitude) ?? 0.0, longitude: Double(longitude) ?? 0.0)
        let geocoder = CLGeocoder()
        
        geocoder.reverseGeocodeLocation(cllLocation) { placemarks, error in
                if let error = error {
                    print(error.localizedDescription)
                } else {
                    if let placemarks = placemarks {
                        placemark = placemarks.first
                        
                        let urlString = "https://api.sunrise-sunset.org/json?lat=\(latitude)&lng=\(longitude)"
                        guard let url = URL(string: urlString) else {
                            print("Malformed URL: \(urlString)")
                            return
                        }
                        guard let jsonData = try? Data(contentsOf: url) else {
                            print("Could not look up sunrise or sunset")
                            return
                        }
                        guard let api = try? JSONDecoder().decode(SunriseSunsetAPI.self, from: jsonData) else {
                            print("Could not decode JSON API:\n\(String(data: jsonData, encoding: .utf8) ?? "<empty>")")
                            return
                        }
                        let inputFormatter = DateFormatter()
                        inputFormatter.dateStyle = .none
                        inputFormatter.timeStyle = .medium
                        inputFormatter.timeZone = .init(secondsFromGMT: 0)
                        
                        let outputFormatter = DateFormatter()
                        outputFormatter.dateStyle = .none
                        outputFormatter.timeStyle = .medium
                        outputFormatter.timeZone = TimeZone(identifier: placemark?.timeZone?.identifier ?? TimeZone.current.identifier)
                        var converted = api.results
                        if let time = inputFormatter.date(from: api.results.sunrise) {
                            converted.sunrise = outputFormatter.string(from: time)
                            print(time)
                        }
                        if let time = inputFormatter.date(from: api.results.sunset) {
                            converted.sunset = outputFormatter.string(from: time)
                            print(time)
                        }
                        self.sunriseSunset = converted
                        print(self.sunriseSunset.sunrise)
                        print(self.sunriseSunset.sunset)
                        
                    }
                }
        }

    }

}
