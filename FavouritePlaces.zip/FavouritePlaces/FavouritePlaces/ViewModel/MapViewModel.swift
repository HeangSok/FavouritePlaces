//
//  MapViewModel.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 12/5/2022.
//

import Foundation
import MapKit
import SwiftUI
import CoreLocation
import Combine


/// This *extension* will make it easy for the developer to read and write to the **MKCoordinateRegion**.
extension MKCoordinateRegion {
    
    /**
        **mapLatitude** is used for reading and writing to *center.latitude*.
     
        **Note:**
        - The lowest number for the latitude is -90 and the largest is 90.
        - If the user does not input the value between -90 and 90 degrees for latitude the app will crash. So, we need to handle it here.
        - To solve this issue, we use the following logics:
            - If the user input the value between -90 and 90, use that value
            - If the user input the value smaller than -90, use -90 instead of letting the app crashing
            - If the user input the value bigger than 90, use 90 instead of letting the app crashing
     */
    var mapLatitude: String {
        get {String(center.latitude)}
        set {
            if -90.00 < Double(newValue) ?? 0.0 && Double(newValue) ?? 00 < 90.00 {
                guard let valueInDegree = Double(newValue) else {return}
                center.latitude = valueInDegree
            } else if (Double(newValue) ?? 0.0 < -90.00) {
                let valueInDegree = -90.00
                center.latitude = valueInDegree
            } else if (Double(newValue) ?? 0.0 > 90.00) {
                let valueInDegree = 90.00
                center.latitude = valueInDegree
            } else {
                guard let valueInDegree = Double(newValue) else {return}
                center.latitude = valueInDegree
            }
        }
    }
    /**
        **mapLongitude** is used for reading and writing to *center.longtitude*.
     
        **Note:**
        - The lowest number for the logitude is -180 and the largest is 180.
        - If the user does not input the value between -180 and 180 degrees for longitude the app will crash. So, we need to handle it here.
        - To solve this issue, we use the following logics:
            - If the user input the value between -180 and 180, use that value
            - If the user input the value smaller than -180, use -180 instead of letting the app crashing
            - If the user input the value bigger than 180, use 180 instead of letting the app crashing
     */
    var mapLongitude: String {
        get {String(center.longitude)}
        set {
            if -180.00 < Double(newValue) ?? 0.0 && Double(newValue) ?? 0.0 < 180.00 {
            guard let valueInDegree = Double(newValue) else {return}
            center.longitude = valueInDegree
            } else if (Double(newValue) ?? 0.0 < -180.00) {
                let valueInDegree = -180.00
                center.longitude = valueInDegree
            } else if (Double(newValue) ?? 0.0 > 180.00) {
                let valueInDegree = 180.00
                center.longitude = valueInDegree
            } else {
                guard let valueInDegree = Double(newValue) else {return}
                center.longitude = valueInDegree
            }
            
        }
        
    }
    
}
