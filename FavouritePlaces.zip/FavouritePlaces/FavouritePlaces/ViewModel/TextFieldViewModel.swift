//
//  TextFieldViewModel.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 23/5/2022.
//

import SwiftUI
import Foundation

/// This *extension* will allow use to customer build our own *Textfield's placeholder*
extension View {
    /**
        placeholder Function
     
        It allows the users to customise the **TextField's** placeholder color.
     */
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View {

        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}
