//
//  FavouritePlacesViewModel.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 5/5/2022.
//
// todo : create placeholder for entity attribute and image to imporve performance

import CoreData
import CoreLocation
import Combine
import MapKit
import Foundation
import SwiftUI

/// This **let defaultImage** store a **Default Image**.
fileprivate let defaultImage = Image(systemName: "photo")
/// This **var downloadedImages** will be a **cache** for storing an *image*.
fileprivate var downloadedImages = [URL : Image]()


/// This *extension* will make it easy for the developer to read and write to the **FavouritePlaces** entity.
extension FavouritePlaces {
    // Non-optional ViewModel property for (optional) `kind` database attribute
    /// this new property will be used with **wrappedValue** when saving the *imageURL*.
    var urlString: String {
        /// if **imageURL** is *URL* type, turn it to string else empty string.
        get { imageURL?.absoluteString ?? "" }
        set {
            guard let url = URL(string: newValue) else { return }
            imageURL = url
            save()
        }
    }
    /// this new property will be used with **wrappedValue** when saving *latitude*.
    var numberOflatitude: String {
        get { String(latitude)}
        set {
            guard let la = Double(newValue) else {return}
            latitude = la
            save()
        }
    }
    /// this new property will be used with **wrappedValue** when saving *longitude*.
    var numberOfLongitude: String {
        get {String(longitude)}
        set {
            guard let long = Double(newValue) else {return}
            longitude = long
            save()
        }
    }
    /// this new property will be used with **wrappedValue** when saving *name*.
    var nameOfPlace: String {
        get {name ?? ""}
        set {
            name = newValue
            save()
        }
        
    }
    /// this new property will be used with **wrappedValue** when saving *locationDetail*.
    var detail: String {
        get {locationDetail ?? ""}
        set {
            locationDetail = newValue
            save()
        }
    }
    
    /// this new property will handle with Date.
    var date: Date {
        get {timestamp ?? Date()}
    }
    
    
    /**
        getImage Function
     
        It will load an image by a given URL
        
        - Returns: It return either the default image or the downloaded image
     */
    func getImage() async -> Image {
        guard let url = imageURL else { return defaultImage }
        if let image = downloadedImages[url] { return image }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            print("Downloaded \(response.expectedContentLength) bytes.")
            guard let uiImg = UIImage(data: data) else { return defaultImage }
            let image = Image(uiImage: uiImg).resizable()
            downloadedImages[url] = image
            return image
        } catch {
            print("Error downloading \(url): \(error.localizedDescription)")
        }
        return defaultImage
    }
    
    // <-------save to core data ---------->
    /**
        Save Function
        
        It saves new value to the Database
     
        - Returns: Bool
     */
    @discardableResult
    func save() -> Bool {
        do {
            try managedObjectContext?.save()
        } catch {
            print("Error saving: \(error)")
            return false
        }
        return true
    }
    
}
