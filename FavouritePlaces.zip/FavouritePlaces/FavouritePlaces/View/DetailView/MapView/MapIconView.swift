//
//  MapView.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 12/5/2022.
//

import SwiftUI
import MapKit
/// **MapIconView** is responsible for showing the map icon.
struct MapIconView: View {
    /// **favouritePlaces** is an ObservedObject; this allows the value to be updated on the screen at runtime.
    @ObservedObject var favouritePlaces: FavouritePlaces
    /// **region** is used as a binding in **Map** view.
    @State var region = MKCoordinateRegion()
    

    var body: some View {
            Map(coordinateRegion: $region)
            .frame(width: 40, height: 35, alignment: .center)
            .border(.gray.opacity(0.2))
            .onAppear{
                region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: Double(favouritePlaces.numberOflatitude) ?? 0.0, longitude: Double(favouritePlaces.numberOfLongitude) ?? 0.0), latitudinalMeters: 5000, longitudinalMeters: 5000)
            }
        
        }
    }

