//
//  MapMainPageView.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 12/5/2022.
//

import SwiftUI
import MapKit
/// **MapMainPageView** is responsible for showing the map page.
struct MapMainPageView: View {
    /// This line of code is useful for customising the < Go Back button.
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    /// **favouritePlaces** is an ObservedObject; this allows the value to be updated on the screen at runtime.
    @ObservedObject var favouritePlaces: FavouritePlaces
    /// **place** is an ObservedObject; this allows the value to be updated on the screen at runtime.
    @ObservedObject var place:GeoLocationViewModel
    /// Show the edit page when the user clicks **Edit** button
    @State var editButtonIsClicked:Bool = false
    /// **lat** is used as a binding value in the **TextField** view
    @State private var lat = ""
    /// **long** is used as a binding value in the **TextField** view
    @State private var long = ""
    /// **name** is used as a binding value in the **TextField** view
    @State private var name = ""

    var body: some View {

        VStack {
            if editButtonIsClicked == true {
                HStack {
                    Button {
                        print("Searched for the location name")
                        let newLocation = CLLocation(latitude: place.region.center.latitude, longitude: place.region.center.longitude)
                        place.lookupName(for: newLocation)
                        name = place.name // note: this line might run and finish before the place.lookupName(for: newLocation); this mean it still have the old value. To solve this issue, place name = place.name when click done
                        print("---\(name)")
                    } label: {
                        Image(systemName:"text.magnifyingglass")
//                            .foregroundColor(.green)
                            .font(.system(size: 30))
                            .shadow(color: .gray, radius: 3)
                    }
                    TextField("Enter name", text: $place.name).onAppear{
                        name = place.name
                        print("---\(name)---")
                    }
                    .onSubmit {
                            place.getCoordinates(for: place.name)
                            name = place.name
                        print("---\(name)")
                        }
                        .textFieldStyle(.roundedBorder)
                }
                .padding(.horizontal)
                Map(coordinateRegion: $place.region)

                HStack{
                    Button {
                        print("Looking up ")
                        place.getCoordinates(for: place.name)
                        name = place.name
                        print("--->\(name)")
                    
                    } label: {
                        Image(systemName:"globe.asia.australia.fill")
                            .font(.system(size: 60))
                            .shadow(color: .gray, radius: 5)
                    }
                    
                    VStack(alignment: .leading) {
                        HStack {
                            Text("   Latitude:").font(.headline)
                            TextField("",  text: $lat)
                                .onSubmit {
                                /// When the user hits **Enter**, we save the *latitude* to the **CoreData**.
                                    place.region.mapLatitude = lat
                                    $favouritePlaces.numberOflatitude.wrappedValue = place.region.mapLatitude
//                                print(favouritePlaces.numberOflatitude)
                                    lat = ""
                                }
                            .lineLimit(1)
//                            .textFieldStyle(.roundedBorder) // note: if we use this line of code the placeholder function will not work
                            .disableAutocorrection(true)
                            .placeholder(when: lat.isEmpty) {
                                Text("\(place.region.mapLatitude)").foregroundColor(.black)
                    }

                        }
                        
                        HStack {
                            Text("Longitude:").font(.headline)
                            TextField("", text: $long)
                                .onSubmit {
                                /// When the user hits **Enter**, we save the *logitude* to the **CoreData**.
                                    place.region.mapLongitude = long
                                    $favouritePlaces.numberOfLongitude.wrappedValue = place.region.mapLongitude
//                                    print(place.region.mapLatitude)
                                    long = ""
                                }
                            .lineLimit(1)
                            //                            .textFieldStyle(.roundedBorder) // note: if we use this line of code the placeholder function will not work
                            .disableAutocorrection(true)
                            .placeholder(when: long.isEmpty) {
                                Text("\(place.region.mapLongitude)").foregroundColor(.black)
                    }

                        }
                    }
                }.padding(.horizontal)

                
            } else {
                Map(coordinateRegion: $place.region)

                Text("Latitude: \(place.region.mapLatitude)")
                Text("Longitude: \(place.region.mapLongitude)")
            }
        }
//        .navigationTitle("Map of \(favouritePlaces.nameOfPlace)")
        .navigationTitle(editButtonIsClicked ? "Map of \(place.name)": "Map of \(favouritePlaces.nameOfPlace)")
        // Build a custom back button
        .navigationBarBackButtonHidden(true)
        .toolbar {
            // custom build < Go Back Button
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action : {
                        self.mode.wrappedValue.dismiss()
                }, label: {
                        
                    HStack{
                        Image(systemName: "chevron.left")
                        Text("Go Back")
                    }
                            })
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                if !editButtonIsClicked{
                    Button(action: {
                        editButtonIsClicked = !editButtonIsClicked
                        // do something in future
                    }, label: {Text("Edit")})
                } else {
                    Button(action: {
                        // when clicking Done it will save all the data
                        editButtonIsClicked = !editButtonIsClicked
                        /// When the user clicks **Done**, we save the *latitude* to the **CoreData**.
                        $favouritePlaces.numberOflatitude.wrappedValue = place.region.mapLatitude
                        /// When the user clicks **Done**, we save the *logitude* to the **CoreData**.
                        $favouritePlaces.numberOfLongitude.wrappedValue = place.region.mapLongitude
                        
                        // note: we have to use name instead of place.name or the CoreData won't save at all. It might shows that it saves the data, but when you restart the simulator, you will see that it does not save at all.
                        name = place.name
                        print(name)
                        $favouritePlaces.nameOfPlace.wrappedValue = name
                        
                    }, label: {Text("Done")})
                }
            }
        }
        }
    }

