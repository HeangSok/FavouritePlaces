//
//  AddFavouritePlaceView.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 5/5/2022.
//

import SwiftUI
import MapKit
/// **FavouritePlaceDetailView** is view that shows the detail of each favourite place.
struct FavouritePlaceDetailView: View {
    
//    @Environment(\.editMode) var editMode
    /// This line of code will be used for saving when there are changes to the database.
//    @Environment(\.managedObjectContext) private var viewContext
    /// **favouritePlaces** is an ObservedObject; this allows the value to be updated on the screen at runtime.
    @ObservedObject var favouritePlaces: FavouritePlaces
    /// **imageURL** will be used in *TextField View*
    @State private var imageURL = ""
    /// **latitude** will be used in *TextField View*
    @State private var name = ""
    /// **locationDetail** will be used in *TextField View*
    @State private var locationDetail = ""
//    @State private var defaultImage = Image(systemName: "photo")
    /// **editButtonIsClicked** is used to check whether the edit button is clicked or not
    @State var editButtonIsClicked:Bool = false
    /// **region** will be used in *Map* view.
    var region: MKCoordinateRegion {
        return MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: Double(favouritePlaces.numberOflatitude) ?? 0.0, longitude: Double(favouritePlaces.numberOfLongitude) ?? 0.0), latitudinalMeters: 5000, longitudinalMeters: 5000)
    }
    
    
    var body: some View {
        List {
                if editButtonIsClicked == true {
                
                    TextField("Favourite Place Name", text: $name)
                        .onChange(of: name) { newValue in
                            $favouritePlaces.nameOfPlace.wrappedValue = name
                        }
                        .disableAutocorrection(true)
                    Section{
                        TextField("Image URL", text: $imageURL).disableAutocorrection(true)
                    } header: {
                        Text("Enter Image URL:")
                    }
                    Section{
                        TextField("Location detail", text: $locationDetail)
                            .disableAutocorrection(true)
                    } header: {
                        Text("Enter Location Details:")
                    }

                } else {
                    FavouritePlaceMainView(favouritePlaces: favouritePlaces, place: GeoLocationViewModel(region: region, name: favouritePlaces.nameOfPlace))

                }
            
        }
        .navigationTitle(favouritePlaces.nameOfPlace)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if !editButtonIsClicked{
                    Button(action: {
                        editButtonIsClicked = !editButtonIsClicked
                        // do something in future
                    }, label: {Text("Edit")})
                } else {
                    Button(action: {
                        // when clicking Done it will save all the data
                        editButtonIsClicked = !editButtonIsClicked
                        $favouritePlaces.urlString.wrappedValue = imageURL
                        
                        if locationDetail == ""{
                            return
                        } else{
                            $favouritePlaces.detail.wrappedValue = locationDetail
                        }

                        // do something in future
                    }, label: {Text("Done")})
                }
            }
        }
    }
}
