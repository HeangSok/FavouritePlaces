//
//  FavouritePlaceEditView.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 5/5/2022.
//

import SwiftUI
import MapKit
/// **FavouritePlaceMainView** is responsible for showing the main detail view of a favourite place when it is not in the edit mode.
struct FavouritePlaceMainView: View {
    /// **favouritePlaces** is an ObservedObject; this allows the value to be updated on the screen at runtime.
    @ObservedObject var favouritePlaces: FavouritePlaces
    /// **place** is an ObservedObject; this allows the value to be updated on the screen at runtime.
    @ObservedObject var place:GeoLocationViewModel
    /// **image** is used for storing Image view.
    @State var image = Image(systemName: "photo")

    var body: some View {

        Section{
            image.aspectRatio(contentMode: .fit)
                .padding(.top)
            
            NavigationLink{
                MapMainPageView(favouritePlaces: favouritePlaces , place: place)
                
            } label: {
                HStack{
                    MapIconView(favouritePlaces: favouritePlaces)
                    Spacer()
                    Text("Map of \(favouritePlaces.nameOfPlace)").font(.headline)
                }
            }
            
            Text(favouritePlaces.detail)
            
        }
        /// **task** is used to work with *Async Fuction*.
        .task{
            image = await favouritePlaces.getImage()
        }
        
        Section {
            HStack {
                
                Label("\(place.sunrise)", systemImage: "sunrise")
                Spacer()
                Label("\(place.sunset)",  systemImage: "sunset")
                
            }
            .onAppear {
                place.lookupSunriseAndSunset(la: favouritePlaces.numberOflatitude, long: favouritePlaces.numberOfLongitude)
            }
            .padding()
        }
        
    }
}

