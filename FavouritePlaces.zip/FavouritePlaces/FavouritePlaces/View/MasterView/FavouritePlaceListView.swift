//
//  FavouritePlaceListView.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 6/5/2022.
//
import CoreData
import SwiftUI
/// **FavouritePlaceListView** is a view that responsibles for showing a list of favourite places.
struct FavouritePlaceListView: View {
    /// This gets data from **CoreData**
    @FetchRequest var favouritePlaces: FetchedResults<FavouritePlaces>
    /// This line of code will be used for saving when there are changes to the database.
    @Environment(\.managedObjectContext) var viewContext
    
    /// Initiatiate here so that we can inject the sortDescripter from outside
    init(sortDescripter: NSSortDescriptor) {
        let request: NSFetchRequest<FavouritePlaces> = FavouritePlaces.fetchRequest()
        request.sortDescriptors = [sortDescripter]
        _favouritePlaces = FetchRequest<FavouritePlaces>(fetchRequest: request)
    }
    
    
    var body: some View {
        
        ForEach(favouritePlaces) { favouritePlace in
            NavigationLink {
                FavouritePlaceDetailView(favouritePlaces: favouritePlace)
            } label: {
                FavouritePlaceRowView(favouritePlaces: favouritePlace)
            }
        }
        .onDelete(perform: deleteFavouritePlace)
        
        
    }
    /**
        Delete a row from the entity.
     
        **Usage Example:**
        ```
        offsets.map { favouritePlaces[$0] }.forEach(viewContext.delete)
        ```
        - Parameter offsets: it takes the IndexSet of set type
     */
    private func deleteFavouritePlace(offsets: IndexSet) {
        withAnimation {
            offsets.map { favouritePlaces[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

}


