//
//  ContentView.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 5/5/2022.
//

import SwiftUI
import CoreData

struct ContentView: View {
    /// This line of code will be used for saving when there are changes to the database.
    @Environment(\.managedObjectContext) private var viewContext
    /// this the default sorting method.
    @State var sortDescriptor: NSSortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.name, ascending: true)
    /// This is a type of sorting
    @State var sortedBy = "Name"
    /// this is a type of ordering
    @State var order = "Ascending"
    /// this is a list of all types of sorting.
    let typeOfSortedData = ["Name", "Date"]
    /// this is a list of all types of ordering.
    let sortedOrder = ["Ascending", "Descening"]

    /// This makes the **Section view** footer to 0
    init() {
               UITableView.appearance().sectionFooterHeight = 0
            }

    var body: some View {

        NavigationView {
            List {
                Section{
                    Picker(selection: $sortedBy, label: Text("Sorted By").font(.headline)) {
                            ForEach(typeOfSortedData, id: \.self) {
                                Text("\($0)")
                        }
                    }
                    .onChange(of: sortedBy) { type in
                        sortedBy = type
                        if sortedBy == "Date" && order == "Ascending" {
                        sortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.timestamp, ascending: true)
                        } else if sortedBy == "Date" && order == "Descening"{
                            sortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.timestamp, ascending: false)
                        } else if sortedBy == "Name" && order == "Ascending" {
                            sortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.name, ascending: true)
                        } else if sortedBy == "Name" && order == "Descening" {
                            sortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.name, ascending: false)
                        }
                        
                    }
                    Picker(selection: $order, label: Text("Sorted By").font(.headline)) {
                        ForEach(sortedOrder, id: \.self) {
                            Text("\($0)")
                            
                        }
                    }.pickerStyle(.segmented)
                     .onChange(of: order) { ord in
                            order = ord
                            if sortedBy == "Date" && order == "Ascending" {
                            sortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.timestamp, ascending: true)
                            } else if sortedBy == "Date" && order == "Descening"{
                                sortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.timestamp, ascending: false)
                            } else if sortedBy == "Name" && order == "Ascending" {
                                sortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.name, ascending: true)
                            } else if sortedBy == "Name" && order == "Descening" {
                                sortDescriptor = NSSortDescriptor(keyPath: \FavouritePlaces.name, ascending: false)
                            }
                            
                        }
                }
                
                FavouritePlaceListView(sortDescripter: sortDescriptor)
                
            }
            .navigationTitle("Favourite Places")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: addFavouritePlace) {
                        Label("Add Favourite Place", systemImage: "plus")
                    }
                }
            }
            
        }
    }

    /**
        Add a new row to the entity.
     
        **Usage Example:**
        ```
         let newFavouritePlace = FavouritePlaces(context: viewContext)
         // line of code make the character of the name become last
         let lastAsciiCharacter = String(UnicodeScalar(UInt8(127)))
         newFavouritePlace.id = UUID()
         newFavouritePlace.name = "\(lastAsciiCharacter)New Favourite Place"
         newFavouritePlace.locationDetail = "Detail..."
         newFavouritePlace.timestamp = Date()
        ```
     */
    private func addFavouritePlace() {
        withAnimation {
            let newFavouritePlace = FavouritePlaces(context: viewContext)
            /// this line of code make the character of the name become last
            let lastAsciiCharacter = String(UnicodeScalar(UInt8(127)))
            newFavouritePlace.id = UUID()
            newFavouritePlace.name = "\(lastAsciiCharacter)New Favourite Place"
            newFavouritePlace.locationDetail = "Detail..."
            newFavouritePlace.timestamp = Date()

            do {
                try viewContext.save()
            } catch {

                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
