//
//  favouritePlaceRow.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 5/5/2022.
//

import SwiftUI
/// **FavouritePlaceRowView** is a view that responsible for showing each row of favourite place list.
struct FavouritePlaceRowView: View {
    /// **favouritePlaces** is an ObservedObject; this allows the value to be updated on the screen at runtime.
    @ObservedObject var favouritePlaces: FavouritePlaces
    /// **image** is used for storing the image view.
    @State var image = Image(systemName: "photo").resizable()
    /// **isNewFavouritePlace** is used for checking if the name of the place has the default name or not.
    var isNewFavouritePlace: Bool {
        get {
            if "\(String(UnicodeScalar(UInt8(127))))New Favourite Place" == favouritePlaces.nameOfPlace {
                return true
            } else {
                return false
            }
        }
    }
    
    var body: some View {
        HStack {
            image.aspectRatio(contentMode: .fill)
                .frame(width: 40, height: 25, alignment: .center)
            VStack(alignment: .leading, spacing: 0.5){
                HStack{
                    Text(favouritePlaces.nameOfPlace)
                        .font(.headline)
                        .lineLimit(1)
//
                    Spacer()
                    Text("\(favouritePlaces.date, formatter: itemFormatter)")
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                        .padding(.trailing)
                }
                
                Text(favouritePlaces.detail)
                    .font(.subheadline)
                    .lineLimit(1)
                    .foregroundColor(.gray)
            }
            
        }
        .background(isNewFavouritePlace ? .mint.opacity(0.1) : .white)
        .cornerRadius(10)
        /// **task** is used to work with *Async Fuction*.
        .task {
            image = await favouritePlaces.getImage()
        }
    }
}

/**
    This changes the date format
 
        - Returns: return a new custome build format.
 */
private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .short
    return formatter
}()
