//
//  FavouritePlacesApp.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 5/5/2022.
//

import SwiftUI

@main
struct FavouritePlacesApp: App {
    /// This property will inject **CoreData** to **SwiftUI**
    let persistenceController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
