//
//  FavouritePlaces+CoreDataProperties.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 20/5/2022.
//
//

import Foundation
import CoreData


extension FavouritePlaces {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<FavouritePlaces> {
        return NSFetchRequest<FavouritePlaces>(entityName: "FavouritePlaces")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var imageURL: URL?
    @NSManaged public var latitude: Double
    @NSManaged public var locationDetail: String?
    @NSManaged public var longitude: Double
    @NSManaged public var name: String?
    @NSManaged public var timestamp: Date?

}
