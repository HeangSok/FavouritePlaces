//
//  FavouritePlaces+CoreDataClass.swift
//  FavouritePlaces
//
//  Created by Heang Sok on 20/5/2022.
//
//

import Foundation
import CoreData

@objc(FavouritePlaces)
public class FavouritePlaces: NSManagedObject {

}
