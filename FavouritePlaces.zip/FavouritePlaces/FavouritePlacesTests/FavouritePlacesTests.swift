//
//  FavouritePlacesTests.swift
//  FavouritePlacesTests
//
//  Created by Heang Sok on 5/5/2022.
//
import XCTest
import MapKit
@testable import FavouritePlaces

// create a model that represent the entity model in core data

final class FavouritePlacesForTest: ObservableObject, Identifiable {
    let id = UUID()
    var imagURL: URL?
    var latitude: Double
    var longitude: Double
    var name: String?
    var locationDetail: String?
    var timestamp: Date?
    
    init(imageURL: URL, latitude: Double, longitude: Double, name: String, locationDetail: String, timestamp: Date){
        self.imagURL = imageURL
        self.latitude = latitude
        self.longitude = longitude
        self.name = name
        self.locationDetail = locationDetail
        self.timestamp = timestamp
    }

}

class FavouritePlacesTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func testFavouritePlacesCoreDataLogic() async throws {
        var favouritePlaces = [FavouritePlacesForTest(imageURL: URL(string: "https://www.google.com/")!, latitude: 0.5, longitude: 0.6, name: "Brisbane", locationDetail: "Brisbane Bridge", timestamp: Date())]
        
        
                // test: get the URL
                var urlString: String {
                    get { favouritePlaces[0].imagURL!.absoluteString}
                }
        
                XCTAssertEqual(urlString == "https://www.google.com/", true)
                XCTAssertEqual(urlString == "https://www.facebook.com/", false)
        
                // test: the latidue
        
                var numberOflatitude: String {
                    get { String(favouritePlaces[0].latitude)}
                }
        
                XCTAssertNotNil(numberOflatitude)
                XCTAssert(numberOflatitude == "0.5")
        
                 // test: longitude
                var numberOfLongitude: String {
                    get {String(favouritePlaces[0].longitude)}
                }
                XCTAssertTrue(numberOfLongitude == "0.6")
                XCTAssertFalse(numberOfLongitude == "0.7")
        
                // test: name
                var nameOfPlace: String {
                    get {favouritePlaces[0].name!}
                }
        
                XCTAssert(nameOfPlace == "Brisbane")
                XCTAssertTrue(nameOfPlace == "Brisbane")
        
                // test: load URL
                let (data, _) = try await URLSession.shared.data(from: (URL(string: urlString)!))
                XCTAssertNotNil(data)
        
                // test: save
                favouritePlaces.append(FavouritePlacesForTest(imageURL: URL(string: "https://www.twitter.com/")!, latitude: 0.5, longitude: 0.6, name: "Sydney", locationDetail: "Sydney street", timestamp: Date()))
                XCTAssertNotNil(favouritePlaces[1])
        
    }
    
    func testGeoLocationClass() async throws {
        
        let geoLocation = GeoLocationViewModel(region: MKCoordinateRegion(center: CLLocationCoordinate2D(latitude:  -27.55, longitude: 153.55), latitudinalMeters: 5000, longitudinalMeters: 5000), name: "Brisbane")
        
        // test: name
        XCTAssert(geoLocation.name == "Brisbane")
        XCTAssertTrue(geoLocation.name == "Brisbane")
        
        // test: sunrise and sunset
        XCTAssertFalse(geoLocation.sunrise == "6.00am")
        XCTAssertTrue(geoLocation.sunrise == "unknown")
        
        XCTAssertFalse(geoLocation.sunset == "5.00pm")
        XCTAssertTrue(geoLocation.sunset == "unknown")
        
        // test: getCoordinates function
        geoLocation.getCoordinates(for: "Gold Coast")
        XCTAssertEqual(abs(geoLocation.region.center.latitude) == 90, false)
        XCTAssertEqual(abs(geoLocation.region.center.longitude) == 180, false)
        
        // test: lookupName function
        geoLocation.lookupName(for: CLLocation(latitude: -27.468590200000065, longitude: 153.02398329999994))
        XCTAssertEqual(geoLocation.name == "Brisbane", true)
        
        // test: lookupSunriseAndSunset
        await geoLocation.lookupSunriseAndSunset(la: "-27.468590200000065", long: "153.02398329999994")
        // since the time for sunrise and sunset are changing everyday, it is not a good practice to test the exact time. So if the scan result is not the "unknown", the test should be considered as success
        XCTAssertEqual(geoLocation.sunrise != "unkown", true)
        XCTAssertEqual(geoLocation.sunset != "unkown", true)
        
    }
    
    func testMapViewModel() throws {
        var region = MKCoordinateRegion()
        
        region.mapLongitude = "180"
        region.mapLatitude = "90"
        // test whether region.mapLongitude and region.mapLatitude write new values to region.center.latitude and region.longitude or not
        XCTAssertTrue(region.center.latitude == 90.00)
        XCTAssertTrue(region.center.longitude == 180.00)
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }


}
